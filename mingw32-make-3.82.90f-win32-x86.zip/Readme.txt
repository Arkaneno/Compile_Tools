Just Rename mingw32-make.exe to make.exe 

So that you can run it as Make on the Command Line or from a Batch file

This runs on Windows XP 32 Bit.